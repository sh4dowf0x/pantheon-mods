﻿Pantheon Combat Data Mod

Requires MelonLoader to already be installed and working for Pantheon.

Install:
1. Copy GameFolder\Mods\PantheonAddonLoader.dll into the game's Mods folder.
2. Copy GameFolder\UserLibs\PantheonAddonFramework.dll into the game's UserLibs folder.
3. Copy GameFolder\Mods\PantheonAddons\CombatData.dll into the game's Mods\PantheonAddons folder.
4. Copy GameFolder\Mods\PantheonAddons\CombatDataConfig.json into the game's Mods\PantheonAddons folder.
5. Remove old AppData addon DLLs if present: %APPDATA%\PantheonAddons\PantheonAddons.dll.

Example game folders:
- Standalone PTR: C:\PantheonPTR\App
- Steam PTR: C:\Program Files (x86)\Steam\steamapps\common\Pantheon Rise of the Fallen (PTR)

Default output folder:
%PUBLIC%\PantheonCombatData

Output files:
- combat-live-current.txt
- combat-live-current.jsonl

Commands:
- /combatdata status
- /combatdata path
- /combatdata clear
- /combatdata save
- /combatdata reopen
- /combatdata messages on|off
- /combatdata structured on|off

Optional custom output folder:
Edit GameFolder\Mods\PantheonAddons\CombatDataConfig.json and set OutputFolder to a location your parser can read.
Restart the client after changing CombatDataConfig.json.

Note:
CombatData.dll contains only the Combat Data addon. It replaces the combat-export use case from the older combined PantheonAddons.dll / Addon Lab setup.
