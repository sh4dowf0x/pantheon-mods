Pantheon Combat Data Mod

Install:
1. Close Pantheon.
2. Copy the Mods and UserLibs folders from this zip into the folder that contains Pantheon.exe.
3. Start Pantheon with MelonLoader.

Files included:
- Mods\PantheonAddonLoader.dll
- UserLibs\PantheonAddonFramework.dll
- Mods\PantheonAddons\CombatData.dll
- Mods\PantheonAddons\CombatDataConfig.json

Default output:
%PROGRAMDATA%\PantheonCombatData\combat-live-CharacterName.txt
%PROGRAMDATA%\PantheonCombatData\combat-live-CharacterName.jsonl

Before the local character is detected, the mod may briefly use combat-live-current.*. JSONL rows include sourceCharacterName and sourceCharacterId.

Commands:
/combatdata status
/combatdata path
/combatdata clear
/combatdata save
/combatdata reopen
/combatdata messages on|off
/combatdata structured on|off
