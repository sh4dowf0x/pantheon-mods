Pantheon Macro Relay Mod

Requires MelonLoader to already be installed and working for Pantheon.

Install:
1. Copy GameFolder\Mods\PantheonAddonLoader.dll into the game's Mods folder.
2. Copy GameFolder\UserLibs\PantheonAddonFramework.dll into the game's UserLibs folder.
3. Copy GameFolder\Mods\PantheonAddons\MacroRelay.dll into the game's Mods\PantheonAddons folder.
4. Copy GameFolder\Mods\PantheonAddons\MacroRelayConfig.json into the game's Mods\PantheonAddons folder.
5. Remove old AppData addon DLLs if present: %APPDATA%\PantheonAddons\PantheonAddons.dll and %APPDATA%\PantheonAddons\MacroRelay.dll.

Example game folders:
- Standalone PTR: C:\PantheonPTR\App
- Steam PTR: C:\Program Files (x86)\Steam\steamapps\common\Pantheon Rise of the Fallen (PTR)

Default relay folder:
%PUBLIC%\PantheonMacroRelay

First test:
1. On the boxed/receiver client, open Pantheon's macro window.
2. Run /macrorelay list to confirm macros are visible.
3. Run /macrorelay receiver on.
4. On the sender client, click a Macro Relay hotbar button or run /macrorelay send <macro name>.

Hotbar:
- Left-click a slot to send its macro request.
- Right-click a slot to edit its label, macro name, and hotkey.
- Use + and - at the top of the hotbar to show more or fewer slots.
- Use /macrorelay hotbar show or /macrorelay hotbar hide.
- Use /macrorelay path to see the active request file and config file locations.

Note:
MacroRelay.dll contains only the Macro Relay addon. If PantheonAddons.dll or an older MacroRelay.dll is still present in %APPDATA%\PantheonAddons, remove it to avoid loading duplicate addons.
