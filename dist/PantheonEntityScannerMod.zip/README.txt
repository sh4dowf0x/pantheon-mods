Pantheon Entity Scanner Mod

Install:
1. Close Pantheon.
2. Copy the Mods and UserLibs folders from this zip into the folder that contains Pantheon.exe.
3. Start Pantheon with MelonLoader.

Files included:
- Mods\PantheonAddonLoader.dll
- UserLibs\PantheonAddonFramework.dll
- Mods\PantheonAddons\EntityScanner.dll
- Mods\PantheonAddons\EntityScannerConfig.json

Default output:
%PROGRAMDATA%\PantheonEntityScanner\entities-live-CharacterName.jsonl

Before the local character is detected, the mod may briefly use entities-live-current.jsonl.

Commands:
/entityscan status
/entityscan path
/entityscan clear
/entityscan save
/entityscan reopen
/entityscan players on|off
/entityscan npcs on|off
/entityscan local on|off
/entityscan distance <meters|0>
