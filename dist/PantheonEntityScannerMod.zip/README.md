# Pantheon Entity Scanner

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\EntityScanner.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
        # Pantheon Combat Data

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\CombatData.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
        # Pantheon Macro Relay

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\MacroRelay.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
        # Pantheon Auto Follow / Follow Beacon

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\FollowBeacon.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
         += "- GameFolder\Mods\PantheonAddons\`n"
    }
     += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Follow Beacon

Follow Beacon is a location-sharing prototype for two Pantheon clients running on the same PC.

One client writes its local player position to a shared JSON file, and another client reads that file to display distance/delta guidance. Follower mode can optionally apply conservative movement assist when `/followbeacon assist on` is enabled.

## Commands

- `/followbeacon leader`: make this client write the shared beacon file.
- `/followbeacon follower`: make this client read the shared beacon file and show guidance.
- `/followbeacon off`: disable reading/writing.
- `/followbeacon show`: show the Follow Beacon window.
- `/followbeacon hide`: hide the Follow Beacon window.
- `/followbeacon status`: show current mode and shared file path.
- `/followbeacon path`: show the shared file path.
- `/followbeacon once`: write one leader beacon immediately.
- `/followbeacon distance <meters>`: set the desired follower distance from the leader.
- `/followbeacon input on|off`: enable or disable manual movement input awareness for `W/A/S/D` and `Q/E`.
- `/followbeacon input status`: show current/last manual input state and event count.
- `/followbeacon input path`: show the manual input event log path.
- `/followbeacon debug on|off`: show or hide raw bearing, delta, and signal age values.
- `/followbeacon probe <input> <seconds>`: manually pulse a movement input for up to 0.5 seconds.
- `/followbeacon probe stop`: stop the current movement probe.
- `/followbeacon assist on|off`: enable or disable conservative follower movement assist.
- `/followbeacon assist status`: show current assist state.

Probe inputs: `forward`, `backward`, `left`, `right`, `sprint`, `turnleft`, `turnright`.

Assist mode is disabled by default. It only runs in follower mode, only with a fresh leader beacon, and pauses when manual input is active, when the follower is within the configured follow distance, when the beacon is stale, or while a movement probe is active. The assist loop holds `turnleft`, `turnright`, and `forward`, recomputes steering from the follower's current heading every frame, and can combine `forward` with a turn input for smoother arcs.

If assist feels too twitchy or too slow, tune `Assist hold scale` in addon configuration. Lower values use shorter assist holds; higher values are more aggressive. `Assist turn deadzone` controls when turn-in-place starts, `Assist move deadzone` controls when it moves straight forward, and `Assist curve deadzone` controls when it can move forward while turning.

Assist can also add `sprint` while moving forward to catch up. By default it starts sprinting at 8m, stops sprinting at 5m, cuts sprint off at 5% endurance, and will not resume sprinting until endurance recovers to 50%.

## Follower Guidance

Follower mode shows smoothed navigation guidance based on the follower's current heading:

- primary action such as `MOVE FORWARD`, `HOLD POSITION`, or `TURN AROUND`
- turn direction and distance to leader
- manual input status and assist eligibility
- last manual movement keys and input-event count
- distance to leader
- signal age and stale warning
- hold/move/turn instruction
- relative bearing in degrees
- smoothed X/Y/Z delta

Raw bearing and delta values are hidden by default. Use `/followbeacon debug on` while tuning.

Input events are appended as JSON lines to:

`%APPDATA%\PantheonAddons\FollowBeacon\input-events.jsonl`

## Shared File

The leader writes:

`%APPDATA%\PantheonAddons\FollowBeacon\leader-location.json`

The file is written atomically through a temporary file so the follower should not read partial JSON.

To override the shared folder, edit `GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json` before starting the game:

```json
{
  "BeaconFolder": "C:\\pantheonmods"
}
```

The config is read when the addon starts. Restart the client after changing it. `/followbeacon path` shows the active shared file and config file locations.
 += "- GameFolder\Mods\PantheonAddons\`n"
    }
    # Pantheon Auto Follow / Follow Beacon

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\FollowBeacon.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
         += "- GameFolder\Mods\PantheonAddons\`n"
    }
     += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Follow Beacon

Follow Beacon is a location-sharing prototype for two Pantheon clients running on the same PC.

One client writes its local player position to a shared JSON file, and another client reads that file to display distance/delta guidance. Follower mode can optionally apply conservative movement assist when `/followbeacon assist on` is enabled.

## Commands

- `/followbeacon leader`: make this client write the shared beacon file.
- `/followbeacon follower`: make this client read the shared beacon file and show guidance.
- `/followbeacon off`: disable reading/writing.
- `/followbeacon show`: show the Follow Beacon window.
- `/followbeacon hide`: hide the Follow Beacon window.
- `/followbeacon status`: show current mode and shared file path.
- `/followbeacon path`: show the shared file path.
- `/followbeacon once`: write one leader beacon immediately.
- `/followbeacon distance <meters>`: set the desired follower distance from the leader.
- `/followbeacon input on|off`: enable or disable manual movement input awareness for `W/A/S/D` and `Q/E`.
- `/followbeacon input status`: show current/last manual input state and event count.
- `/followbeacon input path`: show the manual input event log path.
- `/followbeacon debug on|off`: show or hide raw bearing, delta, and signal age values.
- `/followbeacon probe <input> <seconds>`: manually pulse a movement input for up to 0.5 seconds.
- `/followbeacon probe stop`: stop the current movement probe.
- `/followbeacon assist on|off`: enable or disable conservative follower movement assist.
- `/followbeacon assist status`: show current assist state.

Probe inputs: `forward`, `backward`, `left`, `right`, `sprint`, `turnleft`, `turnright`.

Assist mode is disabled by default. It only runs in follower mode, only with a fresh leader beacon, and pauses when manual input is active, when the follower is within the configured follow distance, when the beacon is stale, or while a movement probe is active. The assist loop holds `turnleft`, `turnright`, and `forward`, recomputes steering from the follower's current heading every frame, and can combine `forward` with a turn input for smoother arcs.

If assist feels too twitchy or too slow, tune `Assist hold scale` in addon configuration. Lower values use shorter assist holds; higher values are more aggressive. `Assist turn deadzone` controls when turn-in-place starts, `Assist move deadzone` controls when it moves straight forward, and `Assist curve deadzone` controls when it can move forward while turning.

Assist can also add `sprint` while moving forward to catch up. By default it starts sprinting at 8m, stops sprinting at 5m, cuts sprint off at 5% endurance, and will not resume sprinting until endurance recovers to 50%.

## Follower Guidance

Follower mode shows smoothed navigation guidance based on the follower's current heading:

- primary action such as `MOVE FORWARD`, `HOLD POSITION`, or `TURN AROUND`
- turn direction and distance to leader
- manual input status and assist eligibility
- last manual movement keys and input-event count
- distance to leader
- signal age and stale warning
- hold/move/turn instruction
- relative bearing in degrees
- smoothed X/Y/Z delta

Raw bearing and delta values are hidden by default. Use `/followbeacon debug on` while tuning.

Input events are appended as JSON lines to:

`%APPDATA%\PantheonAddons\FollowBeacon\input-events.jsonl`

## Shared File

The leader writes:

`%APPDATA%\PantheonAddons\FollowBeacon\leader-location.json`

The file is written atomically through a temporary file so the follower should not read partial JSON.

To override the shared folder, edit `GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json` before starting the game:

```json
{
  "BeaconFolder": "C:\\pantheonmods"
}
```

The config is read when the addon starts. Restart the client after changing it. `/followbeacon path` shows the active shared file and config file locations.
 += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Macro Relay

Macro Relay lets one Pantheon client send a macro request to another client through a shared JSON file.

The boxed/receiver client reads the request file, finds the named in-game macro, and runs it locally. The sender client can use chat commands or the custom Macro Relay hotbar.

## Commands

- `/macrorelay list`: list visible macros on this client.
- `/macrorelay receiver on`: allow this client to receive and run relay requests.
- `/macrorelay receiver off`: stop receiving relay requests.
- `/macrorelay send <macro name>`: send a macro request to the shared relay file.
- `/macrorelay run <macro name>`: run a local macro directly.
- `/macrorelay hotbar show`: show the Macro Relay hotbar.
- `/macrorelay hotbar hide`: hide the Macro Relay hotbar.
- `/macrorelay hotbar reload`: reload hotbar configuration.
- `/macrorelay status`: show receiver/listener state.
- `/macrorelay path`: show the active request file and config file locations.

## Hotbar

- Left-click a slot to send its configured macro request.
- Right-click a slot to edit its label, macro name, and hotkey.
- Use the power button to enable or disable hotkey listening.
- Use `+` and `-` to show more or fewer slots.
- Slots are remembered even when hidden with `-`.
- After 12 visible slots, the hotbar starts a second column.

## Shared File

By default, Macro Relay writes requests under:

`%PUBLIC%\PantheonMacroRelay`

For Sandboxie, two-computer setups, or custom sharing, edit `MacroRelayConfig.json` and set `RelayFolder` to a folder both clients can read and write.
 += "- GameFolder\Mods\PantheonAddons\`n"
    }
    # Pantheon Macro Relay

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\MacroRelay.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
        # Pantheon Auto Follow / Follow Beacon

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\FollowBeacon.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
         += "- GameFolder\Mods\PantheonAddons\`n"
    }
     += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Follow Beacon

Follow Beacon is a location-sharing prototype for two Pantheon clients running on the same PC.

One client writes its local player position to a shared JSON file, and another client reads that file to display distance/delta guidance. Follower mode can optionally apply conservative movement assist when `/followbeacon assist on` is enabled.

## Commands

- `/followbeacon leader`: make this client write the shared beacon file.
- `/followbeacon follower`: make this client read the shared beacon file and show guidance.
- `/followbeacon off`: disable reading/writing.
- `/followbeacon show`: show the Follow Beacon window.
- `/followbeacon hide`: hide the Follow Beacon window.
- `/followbeacon status`: show current mode and shared file path.
- `/followbeacon path`: show the shared file path.
- `/followbeacon once`: write one leader beacon immediately.
- `/followbeacon distance <meters>`: set the desired follower distance from the leader.
- `/followbeacon input on|off`: enable or disable manual movement input awareness for `W/A/S/D` and `Q/E`.
- `/followbeacon input status`: show current/last manual input state and event count.
- `/followbeacon input path`: show the manual input event log path.
- `/followbeacon debug on|off`: show or hide raw bearing, delta, and signal age values.
- `/followbeacon probe <input> <seconds>`: manually pulse a movement input for up to 0.5 seconds.
- `/followbeacon probe stop`: stop the current movement probe.
- `/followbeacon assist on|off`: enable or disable conservative follower movement assist.
- `/followbeacon assist status`: show current assist state.

Probe inputs: `forward`, `backward`, `left`, `right`, `sprint`, `turnleft`, `turnright`.

Assist mode is disabled by default. It only runs in follower mode, only with a fresh leader beacon, and pauses when manual input is active, when the follower is within the configured follow distance, when the beacon is stale, or while a movement probe is active. The assist loop holds `turnleft`, `turnright`, and `forward`, recomputes steering from the follower's current heading every frame, and can combine `forward` with a turn input for smoother arcs.

If assist feels too twitchy or too slow, tune `Assist hold scale` in addon configuration. Lower values use shorter assist holds; higher values are more aggressive. `Assist turn deadzone` controls when turn-in-place starts, `Assist move deadzone` controls when it moves straight forward, and `Assist curve deadzone` controls when it can move forward while turning.

Assist can also add `sprint` while moving forward to catch up. By default it starts sprinting at 8m, stops sprinting at 5m, cuts sprint off at 5% endurance, and will not resume sprinting until endurance recovers to 50%.

## Follower Guidance

Follower mode shows smoothed navigation guidance based on the follower's current heading:

- primary action such as `MOVE FORWARD`, `HOLD POSITION`, or `TURN AROUND`
- turn direction and distance to leader
- manual input status and assist eligibility
- last manual movement keys and input-event count
- distance to leader
- signal age and stale warning
- hold/move/turn instruction
- relative bearing in degrees
- smoothed X/Y/Z delta

Raw bearing and delta values are hidden by default. Use `/followbeacon debug on` while tuning.

Input events are appended as JSON lines to:

`%APPDATA%\PantheonAddons\FollowBeacon\input-events.jsonl`

## Shared File

The leader writes:

`%APPDATA%\PantheonAddons\FollowBeacon\leader-location.json`

The file is written atomically through a temporary file so the follower should not read partial JSON.

To override the shared folder, edit `GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json` before starting the game:

```json
{
  "BeaconFolder": "C:\\pantheonmods"
}
```

The config is read when the addon starts. Restart the client after changing it. `/followbeacon path` shows the active shared file and config file locations.
 += "- GameFolder\Mods\PantheonAddons\`n"
    }
    # Pantheon Auto Follow / Follow Beacon

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\FollowBeacon.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
         += "- GameFolder\Mods\PantheonAddons\`n"
    }
     += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Follow Beacon

Follow Beacon is a location-sharing prototype for two Pantheon clients running on the same PC.

One client writes its local player position to a shared JSON file, and another client reads that file to display distance/delta guidance. Follower mode can optionally apply conservative movement assist when `/followbeacon assist on` is enabled.

## Commands

- `/followbeacon leader`: make this client write the shared beacon file.
- `/followbeacon follower`: make this client read the shared beacon file and show guidance.
- `/followbeacon off`: disable reading/writing.
- `/followbeacon show`: show the Follow Beacon window.
- `/followbeacon hide`: hide the Follow Beacon window.
- `/followbeacon status`: show current mode and shared file path.
- `/followbeacon path`: show the shared file path.
- `/followbeacon once`: write one leader beacon immediately.
- `/followbeacon distance <meters>`: set the desired follower distance from the leader.
- `/followbeacon input on|off`: enable or disable manual movement input awareness for `W/A/S/D` and `Q/E`.
- `/followbeacon input status`: show current/last manual input state and event count.
- `/followbeacon input path`: show the manual input event log path.
- `/followbeacon debug on|off`: show or hide raw bearing, delta, and signal age values.
- `/followbeacon probe <input> <seconds>`: manually pulse a movement input for up to 0.5 seconds.
- `/followbeacon probe stop`: stop the current movement probe.
- `/followbeacon assist on|off`: enable or disable conservative follower movement assist.
- `/followbeacon assist status`: show current assist state.

Probe inputs: `forward`, `backward`, `left`, `right`, `sprint`, `turnleft`, `turnright`.

Assist mode is disabled by default. It only runs in follower mode, only with a fresh leader beacon, and pauses when manual input is active, when the follower is within the configured follow distance, when the beacon is stale, or while a movement probe is active. The assist loop holds `turnleft`, `turnright`, and `forward`, recomputes steering from the follower's current heading every frame, and can combine `forward` with a turn input for smoother arcs.

If assist feels too twitchy or too slow, tune `Assist hold scale` in addon configuration. Lower values use shorter assist holds; higher values are more aggressive. `Assist turn deadzone` controls when turn-in-place starts, `Assist move deadzone` controls when it moves straight forward, and `Assist curve deadzone` controls when it can move forward while turning.

Assist can also add `sprint` while moving forward to catch up. By default it starts sprinting at 8m, stops sprinting at 5m, cuts sprint off at 5% endurance, and will not resume sprinting until endurance recovers to 50%.

## Follower Guidance

Follower mode shows smoothed navigation guidance based on the follower's current heading:

- primary action such as `MOVE FORWARD`, `HOLD POSITION`, or `TURN AROUND`
- turn direction and distance to leader
- manual input status and assist eligibility
- last manual movement keys and input-event count
- distance to leader
- signal age and stale warning
- hold/move/turn instruction
- relative bearing in degrees
- smoothed X/Y/Z delta

Raw bearing and delta values are hidden by default. Use `/followbeacon debug on` while tuning.

Input events are appended as JSON lines to:

`%APPDATA%\PantheonAddons\FollowBeacon\input-events.jsonl`

## Shared File

The leader writes:

`%APPDATA%\PantheonAddons\FollowBeacon\leader-location.json`

The file is written atomically through a temporary file so the follower should not read partial JSON.

To override the shared folder, edit `GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json` before starting the game:

```json
{
  "BeaconFolder": "C:\\pantheonmods"
}
```

The config is read when the addon starts. Restart the client after changing it. `/followbeacon path` shows the active shared file and config file locations.
 += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Macro Relay

Macro Relay lets one Pantheon client send a macro request to another client through a shared JSON file.

The boxed/receiver client reads the request file, finds the named in-game macro, and runs it locally. The sender client can use chat commands or the custom Macro Relay hotbar.

## Commands

- `/macrorelay list`: list visible macros on this client.
- `/macrorelay receiver on`: allow this client to receive and run relay requests.
- `/macrorelay receiver off`: stop receiving relay requests.
- `/macrorelay send <macro name>`: send a macro request to the shared relay file.
- `/macrorelay run <macro name>`: run a local macro directly.
- `/macrorelay hotbar show`: show the Macro Relay hotbar.
- `/macrorelay hotbar hide`: hide the Macro Relay hotbar.
- `/macrorelay hotbar reload`: reload hotbar configuration.
- `/macrorelay status`: show receiver/listener state.
- `/macrorelay path`: show the active request file and config file locations.

## Hotbar

- Left-click a slot to send its configured macro request.
- Right-click a slot to edit its label, macro name, and hotkey.
- Use the power button to enable or disable hotkey listening.
- Use `+` and `-` to show more or fewer slots.
- Slots are remembered even when hidden with `-`.
- After 12 visible slots, the hotbar starts a second column.

## Shared File

By default, Macro Relay writes requests under:

`%PUBLIC%\PantheonMacroRelay`

For Sandboxie, two-computer setups, or custom sharing, edit `MacroRelayConfig.json` and set `RelayFolder` to a folder both clients can read and write.
 += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Combat Data

Combat Data exports Pantheon's rendered combat-log messages, structured combat-result events, and local player XP changes to live text and JSONL files.

## Commands

- `/combatdata status`: show enabled state, counters, buffer count, and file cap.
- `/combatdata path`: show text, JSONL, and config paths.
- `/combatdata clear`: clear live logs and counters.
- `/combatdata save`: save the in-memory text buffer to a timestamped snapshot.
- `/combatdata reopen`: close and reopen the live files.
- `/combatdata messages on|off`: include or skip rendered combat-log messages.
- `/combatdata structured on|off`: include or skip structured combat-result events.
- `/combatdata xp on|off`: include or skip local player experience changes.

## Output

By default, Combat Data writes:

- `%PROGRAMDATA%\PantheonCombatData\combat-live-CharacterName.txt`
- `%PROGRAMDATA%\PantheonCombatData\combat-live-CharacterName.jsonl`

Before the character is loaded, it may briefly use `combat-live-current.*`. Once the local player is detected, it switches to the character-specific file. JSONL rows also include `sourceCharacterName` and `sourceCharacterId`.

Experience rows use category `ExperienceChanged` and include `current`, `toNextLevel`, `experiencePercentage`, previous values, and delta fields. The first XP snapshot after login may have null deltas because Combat Data has no prior sample yet.

The live files rotate to `.previous` when either file reaches the configured size cap.

To override the output folder, edit `GameFolder\Mods\PantheonAddons\CombatDataConfig.json` before starting the game:

```json
{
  "OutputFolder": "C:\\pantheonmods\\combat-data",
  "IncludeCombatMessages": true,
  "IncludeStructuredResults": true,
  "IncludeExperience": true,
  "MaxFileMegabytes": 5
}
```

Restart the client after changing the config. `/combatdata path` shows the active output and config file locations.
 += "- GameFolder\Mods\PantheonAddons\EntityScannerConfig.json`n"
    }
    # Pantheon Combat Data

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\CombatData.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
        # Pantheon Macro Relay

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\MacroRelay.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
        # Pantheon Auto Follow / Follow Beacon

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\FollowBeacon.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
         += "- GameFolder\Mods\PantheonAddons\`n"
    }
     += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Follow Beacon

Follow Beacon is a location-sharing prototype for two Pantheon clients running on the same PC.

One client writes its local player position to a shared JSON file, and another client reads that file to display distance/delta guidance. Follower mode can optionally apply conservative movement assist when `/followbeacon assist on` is enabled.

## Commands

- `/followbeacon leader`: make this client write the shared beacon file.
- `/followbeacon follower`: make this client read the shared beacon file and show guidance.
- `/followbeacon off`: disable reading/writing.
- `/followbeacon show`: show the Follow Beacon window.
- `/followbeacon hide`: hide the Follow Beacon window.
- `/followbeacon status`: show current mode and shared file path.
- `/followbeacon path`: show the shared file path.
- `/followbeacon once`: write one leader beacon immediately.
- `/followbeacon distance <meters>`: set the desired follower distance from the leader.
- `/followbeacon input on|off`: enable or disable manual movement input awareness for `W/A/S/D` and `Q/E`.
- `/followbeacon input status`: show current/last manual input state and event count.
- `/followbeacon input path`: show the manual input event log path.
- `/followbeacon debug on|off`: show or hide raw bearing, delta, and signal age values.
- `/followbeacon probe <input> <seconds>`: manually pulse a movement input for up to 0.5 seconds.
- `/followbeacon probe stop`: stop the current movement probe.
- `/followbeacon assist on|off`: enable or disable conservative follower movement assist.
- `/followbeacon assist status`: show current assist state.

Probe inputs: `forward`, `backward`, `left`, `right`, `sprint`, `turnleft`, `turnright`.

Assist mode is disabled by default. It only runs in follower mode, only with a fresh leader beacon, and pauses when manual input is active, when the follower is within the configured follow distance, when the beacon is stale, or while a movement probe is active. The assist loop holds `turnleft`, `turnright`, and `forward`, recomputes steering from the follower's current heading every frame, and can combine `forward` with a turn input for smoother arcs.

If assist feels too twitchy or too slow, tune `Assist hold scale` in addon configuration. Lower values use shorter assist holds; higher values are more aggressive. `Assist turn deadzone` controls when turn-in-place starts, `Assist move deadzone` controls when it moves straight forward, and `Assist curve deadzone` controls when it can move forward while turning.

Assist can also add `sprint` while moving forward to catch up. By default it starts sprinting at 8m, stops sprinting at 5m, cuts sprint off at 5% endurance, and will not resume sprinting until endurance recovers to 50%.

## Follower Guidance

Follower mode shows smoothed navigation guidance based on the follower's current heading:

- primary action such as `MOVE FORWARD`, `HOLD POSITION`, or `TURN AROUND`
- turn direction and distance to leader
- manual input status and assist eligibility
- last manual movement keys and input-event count
- distance to leader
- signal age and stale warning
- hold/move/turn instruction
- relative bearing in degrees
- smoothed X/Y/Z delta

Raw bearing and delta values are hidden by default. Use `/followbeacon debug on` while tuning.

Input events are appended as JSON lines to:

`%APPDATA%\PantheonAddons\FollowBeacon\input-events.jsonl`

## Shared File

The leader writes:

`%APPDATA%\PantheonAddons\FollowBeacon\leader-location.json`

The file is written atomically through a temporary file so the follower should not read partial JSON.

To override the shared folder, edit `GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json` before starting the game:

```json
{
  "BeaconFolder": "C:\\pantheonmods"
}
```

The config is read when the addon starts. Restart the client after changing it. `/followbeacon path` shows the active shared file and config file locations.
 += "- GameFolder\Mods\PantheonAddons\`n"
    }
    # Pantheon Auto Follow / Follow Beacon

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\FollowBeacon.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
         += "- GameFolder\Mods\PantheonAddons\`n"
    }
     += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Follow Beacon

Follow Beacon is a location-sharing prototype for two Pantheon clients running on the same PC.

One client writes its local player position to a shared JSON file, and another client reads that file to display distance/delta guidance. Follower mode can optionally apply conservative movement assist when `/followbeacon assist on` is enabled.

## Commands

- `/followbeacon leader`: make this client write the shared beacon file.
- `/followbeacon follower`: make this client read the shared beacon file and show guidance.
- `/followbeacon off`: disable reading/writing.
- `/followbeacon show`: show the Follow Beacon window.
- `/followbeacon hide`: hide the Follow Beacon window.
- `/followbeacon status`: show current mode and shared file path.
- `/followbeacon path`: show the shared file path.
- `/followbeacon once`: write one leader beacon immediately.
- `/followbeacon distance <meters>`: set the desired follower distance from the leader.
- `/followbeacon input on|off`: enable or disable manual movement input awareness for `W/A/S/D` and `Q/E`.
- `/followbeacon input status`: show current/last manual input state and event count.
- `/followbeacon input path`: show the manual input event log path.
- `/followbeacon debug on|off`: show or hide raw bearing, delta, and signal age values.
- `/followbeacon probe <input> <seconds>`: manually pulse a movement input for up to 0.5 seconds.
- `/followbeacon probe stop`: stop the current movement probe.
- `/followbeacon assist on|off`: enable or disable conservative follower movement assist.
- `/followbeacon assist status`: show current assist state.

Probe inputs: `forward`, `backward`, `left`, `right`, `sprint`, `turnleft`, `turnright`.

Assist mode is disabled by default. It only runs in follower mode, only with a fresh leader beacon, and pauses when manual input is active, when the follower is within the configured follow distance, when the beacon is stale, or while a movement probe is active. The assist loop holds `turnleft`, `turnright`, and `forward`, recomputes steering from the follower's current heading every frame, and can combine `forward` with a turn input for smoother arcs.

If assist feels too twitchy or too slow, tune `Assist hold scale` in addon configuration. Lower values use shorter assist holds; higher values are more aggressive. `Assist turn deadzone` controls when turn-in-place starts, `Assist move deadzone` controls when it moves straight forward, and `Assist curve deadzone` controls when it can move forward while turning.

Assist can also add `sprint` while moving forward to catch up. By default it starts sprinting at 8m, stops sprinting at 5m, cuts sprint off at 5% endurance, and will not resume sprinting until endurance recovers to 50%.

## Follower Guidance

Follower mode shows smoothed navigation guidance based on the follower's current heading:

- primary action such as `MOVE FORWARD`, `HOLD POSITION`, or `TURN AROUND`
- turn direction and distance to leader
- manual input status and assist eligibility
- last manual movement keys and input-event count
- distance to leader
- signal age and stale warning
- hold/move/turn instruction
- relative bearing in degrees
- smoothed X/Y/Z delta

Raw bearing and delta values are hidden by default. Use `/followbeacon debug on` while tuning.

Input events are appended as JSON lines to:

`%APPDATA%\PantheonAddons\FollowBeacon\input-events.jsonl`

## Shared File

The leader writes:

`%APPDATA%\PantheonAddons\FollowBeacon\leader-location.json`

The file is written atomically through a temporary file so the follower should not read partial JSON.

To override the shared folder, edit `GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json` before starting the game:

```json
{
  "BeaconFolder": "C:\\pantheonmods"
}
```

The config is read when the addon starts. Restart the client after changing it. `/followbeacon path` shows the active shared file and config file locations.
 += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Macro Relay

Macro Relay lets one Pantheon client send a macro request to another client through a shared JSON file.

The boxed/receiver client reads the request file, finds the named in-game macro, and runs it locally. The sender client can use chat commands or the custom Macro Relay hotbar.

## Commands

- `/macrorelay list`: list visible macros on this client.
- `/macrorelay receiver on`: allow this client to receive and run relay requests.
- `/macrorelay receiver off`: stop receiving relay requests.
- `/macrorelay send <macro name>`: send a macro request to the shared relay file.
- `/macrorelay run <macro name>`: run a local macro directly.
- `/macrorelay hotbar show`: show the Macro Relay hotbar.
- `/macrorelay hotbar hide`: hide the Macro Relay hotbar.
- `/macrorelay hotbar reload`: reload hotbar configuration.
- `/macrorelay status`: show receiver/listener state.
- `/macrorelay path`: show the active request file and config file locations.

## Hotbar

- Left-click a slot to send its configured macro request.
- Right-click a slot to edit its label, macro name, and hotkey.
- Use the power button to enable or disable hotkey listening.
- Use `+` and `-` to show more or fewer slots.
- Slots are remembered even when hidden with `-`.
- After 12 visible slots, the hotbar starts a second column.

## Shared File

By default, Macro Relay writes requests under:

`%PUBLIC%\PantheonMacroRelay`

For Sandboxie, two-computer setups, or custom sharing, edit `MacroRelayConfig.json` and set `RelayFolder` to a folder both clients can read and write.
 += "- GameFolder\Mods\PantheonAddons\`n"
    }
    # Pantheon Macro Relay

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\MacroRelay.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
        # Pantheon Auto Follow / Follow Beacon

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\FollowBeacon.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
         += "- GameFolder\Mods\PantheonAddons\`n"
    }
     += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Follow Beacon

Follow Beacon is a location-sharing prototype for two Pantheon clients running on the same PC.

One client writes its local player position to a shared JSON file, and another client reads that file to display distance/delta guidance. Follower mode can optionally apply conservative movement assist when `/followbeacon assist on` is enabled.

## Commands

- `/followbeacon leader`: make this client write the shared beacon file.
- `/followbeacon follower`: make this client read the shared beacon file and show guidance.
- `/followbeacon off`: disable reading/writing.
- `/followbeacon show`: show the Follow Beacon window.
- `/followbeacon hide`: hide the Follow Beacon window.
- `/followbeacon status`: show current mode and shared file path.
- `/followbeacon path`: show the shared file path.
- `/followbeacon once`: write one leader beacon immediately.
- `/followbeacon distance <meters>`: set the desired follower distance from the leader.
- `/followbeacon input on|off`: enable or disable manual movement input awareness for `W/A/S/D` and `Q/E`.
- `/followbeacon input status`: show current/last manual input state and event count.
- `/followbeacon input path`: show the manual input event log path.
- `/followbeacon debug on|off`: show or hide raw bearing, delta, and signal age values.
- `/followbeacon probe <input> <seconds>`: manually pulse a movement input for up to 0.5 seconds.
- `/followbeacon probe stop`: stop the current movement probe.
- `/followbeacon assist on|off`: enable or disable conservative follower movement assist.
- `/followbeacon assist status`: show current assist state.

Probe inputs: `forward`, `backward`, `left`, `right`, `sprint`, `turnleft`, `turnright`.

Assist mode is disabled by default. It only runs in follower mode, only with a fresh leader beacon, and pauses when manual input is active, when the follower is within the configured follow distance, when the beacon is stale, or while a movement probe is active. The assist loop holds `turnleft`, `turnright`, and `forward`, recomputes steering from the follower's current heading every frame, and can combine `forward` with a turn input for smoother arcs.

If assist feels too twitchy or too slow, tune `Assist hold scale` in addon configuration. Lower values use shorter assist holds; higher values are more aggressive. `Assist turn deadzone` controls when turn-in-place starts, `Assist move deadzone` controls when it moves straight forward, and `Assist curve deadzone` controls when it can move forward while turning.

Assist can also add `sprint` while moving forward to catch up. By default it starts sprinting at 8m, stops sprinting at 5m, cuts sprint off at 5% endurance, and will not resume sprinting until endurance recovers to 50%.

## Follower Guidance

Follower mode shows smoothed navigation guidance based on the follower's current heading:

- primary action such as `MOVE FORWARD`, `HOLD POSITION`, or `TURN AROUND`
- turn direction and distance to leader
- manual input status and assist eligibility
- last manual movement keys and input-event count
- distance to leader
- signal age and stale warning
- hold/move/turn instruction
- relative bearing in degrees
- smoothed X/Y/Z delta

Raw bearing and delta values are hidden by default. Use `/followbeacon debug on` while tuning.

Input events are appended as JSON lines to:

`%APPDATA%\PantheonAddons\FollowBeacon\input-events.jsonl`

## Shared File

The leader writes:

`%APPDATA%\PantheonAddons\FollowBeacon\leader-location.json`

The file is written atomically through a temporary file so the follower should not read partial JSON.

To override the shared folder, edit `GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json` before starting the game:

```json
{
  "BeaconFolder": "C:\\pantheonmods"
}
```

The config is read when the addon starts. Restart the client after changing it. `/followbeacon path` shows the active shared file and config file locations.
 += "- GameFolder\Mods\PantheonAddons\`n"
    }
    # Pantheon Auto Follow / Follow Beacon

Copy the contents of GameFolder into your Pantheon game folder after MelonLoader is installed and working.

This package includes:

- GameFolder\Mods\PantheonAddonLoader.dll
- GameFolder\UserLibs\PantheonAddonFramework.dll
- GameFolder\Mods\PantheonAddons\FollowBeacon.dll
"@
    if (System.Collections.Hashtable.ConfigName) {
         += "- GameFolder\Mods\PantheonAddons\`n"
    }
     += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Follow Beacon

Follow Beacon is a location-sharing prototype for two Pantheon clients running on the same PC.

One client writes its local player position to a shared JSON file, and another client reads that file to display distance/delta guidance. Follower mode can optionally apply conservative movement assist when `/followbeacon assist on` is enabled.

## Commands

- `/followbeacon leader`: make this client write the shared beacon file.
- `/followbeacon follower`: make this client read the shared beacon file and show guidance.
- `/followbeacon off`: disable reading/writing.
- `/followbeacon show`: show the Follow Beacon window.
- `/followbeacon hide`: hide the Follow Beacon window.
- `/followbeacon status`: show current mode and shared file path.
- `/followbeacon path`: show the shared file path.
- `/followbeacon once`: write one leader beacon immediately.
- `/followbeacon distance <meters>`: set the desired follower distance from the leader.
- `/followbeacon input on|off`: enable or disable manual movement input awareness for `W/A/S/D` and `Q/E`.
- `/followbeacon input status`: show current/last manual input state and event count.
- `/followbeacon input path`: show the manual input event log path.
- `/followbeacon debug on|off`: show or hide raw bearing, delta, and signal age values.
- `/followbeacon probe <input> <seconds>`: manually pulse a movement input for up to 0.5 seconds.
- `/followbeacon probe stop`: stop the current movement probe.
- `/followbeacon assist on|off`: enable or disable conservative follower movement assist.
- `/followbeacon assist status`: show current assist state.

Probe inputs: `forward`, `backward`, `left`, `right`, `sprint`, `turnleft`, `turnright`.

Assist mode is disabled by default. It only runs in follower mode, only with a fresh leader beacon, and pauses when manual input is active, when the follower is within the configured follow distance, when the beacon is stale, or while a movement probe is active. The assist loop holds `turnleft`, `turnright`, and `forward`, recomputes steering from the follower's current heading every frame, and can combine `forward` with a turn input for smoother arcs.

If assist feels too twitchy or too slow, tune `Assist hold scale` in addon configuration. Lower values use shorter assist holds; higher values are more aggressive. `Assist turn deadzone` controls when turn-in-place starts, `Assist move deadzone` controls when it moves straight forward, and `Assist curve deadzone` controls when it can move forward while turning.

Assist can also add `sprint` while moving forward to catch up. By default it starts sprinting at 8m, stops sprinting at 5m, cuts sprint off at 5% endurance, and will not resume sprinting until endurance recovers to 50%.

## Follower Guidance

Follower mode shows smoothed navigation guidance based on the follower's current heading:

- primary action such as `MOVE FORWARD`, `HOLD POSITION`, or `TURN AROUND`
- turn direction and distance to leader
- manual input status and assist eligibility
- last manual movement keys and input-event count
- distance to leader
- signal age and stale warning
- hold/move/turn instruction
- relative bearing in degrees
- smoothed X/Y/Z delta

Raw bearing and delta values are hidden by default. Use `/followbeacon debug on` while tuning.

Input events are appended as JSON lines to:

`%APPDATA%\PantheonAddons\FollowBeacon\input-events.jsonl`

## Shared File

The leader writes:

`%APPDATA%\PantheonAddons\FollowBeacon\leader-location.json`

The file is written atomically through a temporary file so the follower should not read partial JSON.

To override the shared folder, edit `GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json` before starting the game:

```json
{
  "BeaconFolder": "C:\\pantheonmods"
}
```

The config is read when the addon starts. Restart the client after changing it. `/followbeacon path` shows the active shared file and config file locations.
 += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Macro Relay

Macro Relay lets one Pantheon client send a macro request to another client through a shared JSON file.

The boxed/receiver client reads the request file, finds the named in-game macro, and runs it locally. The sender client can use chat commands or the custom Macro Relay hotbar.

## Commands

- `/macrorelay list`: list visible macros on this client.
- `/macrorelay receiver on`: allow this client to receive and run relay requests.
- `/macrorelay receiver off`: stop receiving relay requests.
- `/macrorelay send <macro name>`: send a macro request to the shared relay file.
- `/macrorelay run <macro name>`: run a local macro directly.
- `/macrorelay hotbar show`: show the Macro Relay hotbar.
- `/macrorelay hotbar hide`: hide the Macro Relay hotbar.
- `/macrorelay hotbar reload`: reload hotbar configuration.
- `/macrorelay status`: show receiver/listener state.
- `/macrorelay path`: show the active request file and config file locations.

## Hotbar

- Left-click a slot to send its configured macro request.
- Right-click a slot to edit its label, macro name, and hotkey.
- Use the power button to enable or disable hotkey listening.
- Use `+` and `-` to show more or fewer slots.
- Slots are remembered even when hidden with `-`.
- After 12 visible slots, the hotbar starts a second column.

## Shared File

By default, Macro Relay writes requests under:

`%PUBLIC%\PantheonMacroRelay`

For Sandboxie, two-computer setups, or custom sharing, edit `MacroRelayConfig.json` and set `RelayFolder` to a folder both clients can read and write.
 += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Combat Data

Combat Data exports Pantheon's rendered combat-log messages, structured combat-result events, and local player XP changes to live text and JSONL files.

## Commands

- `/combatdata status`: show enabled state, counters, buffer count, and file cap.
- `/combatdata path`: show text, JSONL, and config paths.
- `/combatdata clear`: clear live logs and counters.
- `/combatdata save`: save the in-memory text buffer to a timestamped snapshot.
- `/combatdata reopen`: close and reopen the live files.
- `/combatdata messages on|off`: include or skip rendered combat-log messages.
- `/combatdata structured on|off`: include or skip structured combat-result events.
- `/combatdata xp on|off`: include or skip local player experience changes.

## Output

By default, Combat Data writes:

- `%PROGRAMDATA%\PantheonCombatData\combat-live-CharacterName.txt`
- `%PROGRAMDATA%\PantheonCombatData\combat-live-CharacterName.jsonl`

Before the character is loaded, it may briefly use `combat-live-current.*`. Once the local player is detected, it switches to the character-specific file. JSONL rows also include `sourceCharacterName` and `sourceCharacterId`.

Experience rows use category `ExperienceChanged` and include `current`, `toNextLevel`, `experiencePercentage`, previous values, and delta fields. The first XP snapshot after login may have null deltas because Combat Data has no prior sample yet.

The live files rotate to `.previous` when either file reaches the configured size cap.

To override the output folder, edit `GameFolder\Mods\PantheonAddons\CombatDataConfig.json` before starting the game:

```json
{
  "OutputFolder": "C:\\pantheonmods\\combat-data",
  "IncludeCombatMessages": true,
  "IncludeStructuredResults": true,
  "IncludeExperience": true,
  "MaxFileMegabytes": 5
}
```

Restart the client after changing the config. `/combatdata path` shows the active output and config file locations.
 += @"

Remove older split addon DLLs from %APPDATA%\PantheonAddons if you previously installed early test builds there.
## Mod Notes

# Pantheon Entity Scanner

Exports nearby player, NPC, and local-character snapshots to JSONL for external parsers or database import.

## Install

Copy these files into the game folder:

- `Mods/PantheonAddonLoader.dll`
- `UserLibs/PantheonAddonFramework.dll`
- `Mods/PantheonAddons/EntityScanner.dll`
- optional: `Mods/PantheonAddons/EntityScannerConfig.json`

## Output

Default output folder:

`%PROGRAMDATA%\PantheonEntityScanner`

Live file:

`entities-live-CharacterName.jsonl`

Before the character is loaded, it may briefly use `entities-live-current.jsonl`. Once the local player is detected, it switches to the character-specific file.

## Commands

- `/entityscan status`
- `/entityscan path`
- `/entityscan clear`
- `/entityscan save`
- `/entityscan reopen`
- `/entityscan players on|off`
- `/entityscan npcs on|off`
- `/entityscan local on|off`
- `/entityscan distance <meters|0>`
