Pantheon Auto-Follow Mod

Requires MelonLoader to already be installed and working for Pantheon.

Install:
1. Copy GameFolder\Mods\PantheonAddonLoader.dll into the game's Mods folder.
2. Copy GameFolder\UserLibs\PantheonAddonFramework.dll into the game's UserLibs folder.
3. Remove old combined addon files if present: %APPDATA%\PantheonAddons\PantheonAddons.dll.
4. Copy AppData\PantheonAddons\FollowBeacon.dll into %APPDATA%\PantheonAddons\FollowBeacon.dll.
5. Optional for Sandboxie or multi-install setups: copy GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json into the game's Mods\PantheonAddons folder and set BeaconFolder to a location both clients can read and write.

Example game folders:
- Standalone PTR: C:\PantheonPTR\App
- Steam PTR: C:\Program Files (x86)\Steam\steamapps\common\Pantheon Rise of the Fallen (PTR)

The Follow Controls window provides buttons for Leader, Follower, and Auto-Follow.
The larger status window is hidden by default and can be opened with /followbeacon show.
Use /followbeacon path in game to see the active beacon file and config file locations.
