Pantheon Auto-Follow Mod

Requires MelonLoader to already be installed and working for Pantheon.

Install:
1. Copy GameFolder\Mods\PantheonAddonLoader.dll into the game's Mods folder.
2. Copy GameFolder\UserLibs\PantheonAddonFramework.dll into the game's UserLibs folder.
3. Copy GameFolder\Mods\PantheonAddons\FollowBeacon.dll into the game's Mods\PantheonAddons folder.
4. Copy GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json into the game's Mods\PantheonAddons folder.
5. Remove old AppData addon DLLs if present: %APPDATA%\PantheonAddons\PantheonAddons.dll and %APPDATA%\PantheonAddons\FollowBeacon.dll.
6. Optional for Sandboxie or multi-install setups: edit GameFolder\Mods\PantheonAddons\FollowBeaconConfig.json and set BeaconFolder to a location both clients can read and write.

Example game folders:
- Standalone PTR: C:\PantheonPTR\App
- Steam PTR: C:\Program Files (x86)\Steam\steamapps\common\Pantheon Rise of the Fallen (PTR)

The Follow Controls window provides buttons for Leader, Follower, and Auto-Follow.
The larger status window is hidden by default and can be opened with /followbeacon show.
Use /followbeacon path in game to see the active beacon file and config file locations.
